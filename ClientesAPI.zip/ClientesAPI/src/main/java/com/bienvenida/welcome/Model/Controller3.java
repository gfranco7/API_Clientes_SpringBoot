package com.bienvenida.welcome.Model;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class Controller3 {

    @GetMapping("api/cliente")
    public String cliente(Model model){
        ArrayList clientes = new ArrayList();

        clientes.add(new Cliente("Victor", 22));
        clientes.add(new Cliente("ALexis", 15));
        clientes.add(new Cliente("Franco", 23));

        return clientes.toString();

    }


}
